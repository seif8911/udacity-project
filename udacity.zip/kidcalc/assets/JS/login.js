  const form = document.querySelector("#form");
  const infoSection = document.querySelector(".info-section");
  const personalInfo = document.querySelector("#personal-info");
  const changeThemeButtons = document.querySelectorAll(".change-theme");

  form.addEventListener("submit", (e) => {
    e.preventDefault();

    const name = document.querySelector("#name").value;
    const age = document.querySelector("#age").value;
    const theme = document.querySelector("#theme").value;

    personalInfo.innerHTML = `Name: ${name}<br>Age: ${age}<br>Favorite Theme: ${theme}`;

    form.style.display = "none";
    infoSection.style.display = "block";
  });

  changeThemeButtons.forEach((button) => {
    button.addEventListener("click", (e) => {
      const newTheme = e.target.dataset.theme;
      personalInfo.innerHTML += `<br>New Theme: ${newTheme}`;
    });
  });