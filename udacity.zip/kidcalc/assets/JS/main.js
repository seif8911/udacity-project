import './kidcalc';
import './login';
