const expression = document.getElementById("expression");
const answer = document.getElementById("answer");
const submit = document.getElementById("submit");
const clear = document.getElementById("clear");
const result = document.getElementById("result");

const numbers = document.querySelectorAll(".number");
const operators = document.querySelectorAll(".operator");
const logic = document.querySelectorAll(".logic");
const equals = document.getElementById("equals");

numbers.forEach(number => {
  number.addEventListener("click", () => {
    expression.value += number.textContent;
    answer.value = "";
  });
});

operators.forEach(operator => {
  operator.addEventListener("click", () => {
    expression.value += ` ${operator.textContent} `;
    answer.value = "";
  });
});

logic.forEach(op => {
  op.addEventListener("click", () => {
    expression.value += ` ${op.textContent} `;
  });
});

equals.addEventListener("click", () => {
  expression.value += ` ${answer.value}`;
  answer.value = "";
});

clear.addEventListener("click", () => {
  expression.value = "";
  answer.value = "";
});

let correctCount = 0;
const counter = document.getElementById("counter");

submit.addEventListener("click", e => {
  e.preventDefault();
  const input = expression.value.trim();
  try {
    let correctAnswer;
    if (input.includes("<") || input.includes(">")) {
      correctAnswer = eval(input);
      if (correctAnswer) {
        correctCount++;
        result.textContent = "Great job! Correct count: " + correctCount;
      } else {
        result.textContent = "Try again. Correct answer is: " + correctAnswer;
      }
    } else {
      correctAnswer = eval(input);
      if (correctAnswer == answer.value) {
        correctCount++;
        result.textContent = "Great job! Correct count: " + correctCount;
      } else {
        result.textContent = "Try again. Correct answer is: " + correctAnswer;
      }
    }
  } catch (error) {
    result.textContent = "Invalid input";
  }
    counter.textContent = "Correct count✅: " + correctCount;
});
